﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommonClasses
{
    public class Hand
    {
        private List<Card> cards = new List<Card>();
        public List<Card> Cards
        {
            get { return cards; }
            set { cards = value; }
        }

        private int total;
        public int Total
        {
            get { return total; }
            set { total = value; }
        }


        public int CalculateTotal()
        {
            Total = 0;

            foreach (Card c in Cards)
            {
                Total += c.NumberValue;
            }

            return Total;
        }

    }
}