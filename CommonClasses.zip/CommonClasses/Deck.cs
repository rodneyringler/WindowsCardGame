﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommonClasses
{
    public class Deck
    {
        private List<Card> cards = new List<Card>();
        public List<Card> Cards 
        {
            get { return cards; }
            set { cards = value; } 
        }


        public void Initialize()
        {   
            string[] suit = new string[4] {"club", "diamond", "heart", "spade"};
            string[] rank = new string[13] {"a", "2", "3", "4", "5", "6", "7", "8", "9", "10", "j", "q", "k"};

            //Clear the cards first.
            Cards.Clear();

            for (int j = 0; j < 4; j++)
            {
                string currentsuit = suit[j];

                for (int i = 0; i <= 12; i++)
                {
                    //Calculate the number value of the card.
                    int numvalue = 0;

                    if (i == 0)
                    {
                        numvalue = 11;
                    }
                    else if (i < 10)
                    {
                        numvalue = i + 1;
                    }
                    else
                    {
                        numvalue = 10;
                    }
                    //Add the card to the deck.
                    string imagename = @"CardImages\" + rank[i] + currentsuit.Substring(0, 1) + ".png";
                    Cards.Add(new Card(currentsuit, rank[i], numvalue, false, false, imagename));
                }
            }
         }

       

        public Card GetCard()
        {
            int randomnumber;
            Card c;

            Random r = new Random();

            //loop until you get a card that has not been dealt.
            //do
            //{
            //    randomnumber = r.Next(0, Cards.Count);
            //    c = Cards[randomnumber];
            //}
            //while (c.Dealt == true);

            randomnumber = r.Next(0, Cards.Count);
            c = Cards[randomnumber];
            c.Dealt = true;
            
            //remove from deck.
            Cards.RemoveAt(randomnumber);

            return c;
        }

    }
}